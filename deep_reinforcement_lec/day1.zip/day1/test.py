import numpy as np
import pandas as pd
import torch as tc

a = [10,20,30,40,50]
print(np.__version__)
print(pd.__version__)
print(tc.__version__)