import torch

t1 = torch.tensor([1,2,3,4,5,6])
print(t1.size())
t2 = t1.view(2,3)
print(t2)
print()

t3 = torch.tensor([[1,2],[3,4],[5,6]])
print(t3)
print()
print(t3.view(-1))
print(t3.view(1, -1))
print()

t4 = torch.tensor([[[1,2],[3,4]],[[5,6],[7,8]]])
print(t4)
print()

print(t4.view(-1))
print(t4.view(1,-1))
print()
print(t4.view(2,-1))