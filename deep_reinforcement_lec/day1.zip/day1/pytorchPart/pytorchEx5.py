import torch

t1 = torch.zeros(2,1,2,1,2)
print(t1.size())
print(t1.squeeze().size())
print(torch.squeeze(t1).size())
print(torch.squeeze(t1, dim=1).size())
print()

t2 = torch.zeros(2,3)
print(t2.size())
print(torch.unsqueeze(t2, dim=0).size())
print(torch.unsqueeze(t2, dim=1).size())
print(torch.unsqueeze(t2, dim=2).size())
print()

import torch.nn.init as init

t3 = init.uniform_(torch.FloatTensor(3,4))
print(t3)
print()

t4 = init.normal_(torch.FloatTensor(3,4))
print(t4)
print()

t4 = init.normal_(torch.FloatTensor(3,4), mean=10, std=4)
print(t4)
print()

t5 = torch.FloatTensor(torch.randn(3,4))
print(t5)
print()

t6 = init.constant_(torch.FloatTensor(3,4), 100)
print(t6)
print()

w = torch.tensor(2., requires_grad=True)
y = 2 * w
y.backward()
print(w.grad)
print()

t7 = torch.tensor(3., requires_grad=True)
for _ in range(20):
    y = 7 * t7
    y.backward()
    print('미분한 값:',t7.grad)
    t7.grad.zero_()
    #optimizer.zero_grad()