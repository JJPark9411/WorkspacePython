import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.init as init
import torch.nn.functional as F

x = init.uniform_(torch.Tensor(1000,1), -10, 10)
value = init.normal_(torch.Tensor(1000,1),std=0.2)
y_target = 2 * x  + 3 + value

model = nn.Linear(1,1)
optimizer = optim.SGD(model.parameters(), lr=0.01)
cost_func = nn.MSELoss()

for epoch in range(500):
    optimizer.zero_grad()
    hypothesis = model(x)
    #cost = F.mse_loss(hypothesis, y_target)
    cost = cost_func(hypothesis, y_target)
    cost.backward()
    optimizer.step()

    if epoch % 10 == 0:
        print('epoch:{}, cost:{:.3f}'.format(epoch, cost.item()))
